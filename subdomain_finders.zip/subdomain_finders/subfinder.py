#!/usr/bin/env python3
"""
subdomain_active_finder.py
Usage:
    python subdomain_active_finder.py example.com -w wordlist.txt -o active.txt -t 50
"""

import argparse
import requests
import dns.resolver
import concurrent.futures
import socket
import sys
import time
from typing import List, Set

# ------- Configurable defaults -------
REQUEST_TIMEOUT = 6
DNS_TIMEOUT = 3
DEFAULT_THREADS = 40
# --------------------------------------

def load_wordlist(path: str) -> List[str]:
    with open(path, 'r', encoding='utf-8', errors='ignore') as f:
        return [line.strip() for line in f if line.strip()]

def fetch_crtsh(domain: str) -> Set[str]:
    """Fetch subdomains from crt.sh (archive of certificates)."""
    url = f"https://crt.sh/?q=%25.{domain}&output=json"
    subs = set()
    try:
        resp = requests.get(url, timeout=10)
        if resp.status_code == 200:
            data = resp.json()
            for entry in data:
                name = entry.get('name_value', '')
                for s in name.splitlines():
                    s = s.strip()
                    if not s:
                        continue
                    # remove wildcard prefix
                    s = s.lstrip('*.')
                    if s.endswith(domain):
                        subs.add(s)
    except Exception as e:
        print(f"[!] crt.sh lookup failed: {e}", file=sys.stderr)
    return subs

def resolve_host(host: str) -> bool:
    """Return True if DNS A/AAAA resolves, False otherwise."""
    try:
        # use dns.resolver with a short timeout
        resolver = dns.resolver.Resolver()
        resolver.timeout = DNS_TIMEOUT
        resolver.lifetime = DNS_TIMEOUT
        answers = resolver.resolve(host, 'A')
        return len(answers) > 0
    except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer, dns.resolver.NoNameservers):
        return False
    except dns.resolver.LifetimeTimeout:
        return False
    except Exception:
        # Some environments will raise different socket errors; treat as unresolved
        return False

def check_http_alive(host: str) -> bool:
    """Check whether host responds on HTTPS or HTTP."""
    schemes = ['https://', 'http://']
    headers = {'User-Agent': 'subdomain-finder/1.0'}
    for scheme in schemes:
        url = scheme + host
        try:
            # try HEAD first (faster), fallback to GET if server does not allow HEAD
            r = requests.head(url, timeout=REQUEST_TIMEOUT, allow_redirects=True, headers=headers, verify=False)
            if r.status_code and r.status_code < 600:
                # any sensible HTTP response code indicates something is listening
                return True
        except requests.exceptions.RequestException:
            # try GET as fallback
            try:
                r = requests.get(url, timeout=REQUEST_TIMEOUT, allow_redirects=True, headers=headers, verify=False)
                if r.status_code and r.status_code < 600:
                    return True
            except requests.exceptions.RequestException:
                continue
    return False

def brute_force(domain: str, wordlist: List[str], threads: int=DEFAULT_THREADS) -> Set[str]:
    print("[*] Starting brute-force DNS checks...")
    found = set()
    def try_word(w):
        sub = f"{w}.{domain}"
        if resolve_host(sub):
            print(f"[+] DNS resolves: {sub}")
            return sub
        return None

    with concurrent.futures.ThreadPoolExecutor(max_workers=threads) as ex:
        futures = {ex.submit(try_word, w): w for w in wordlist}
        for fut in concurrent.futures.as_completed(futures):
            res = fut.result()
            if res:
                found.add(res)
    return found

def filter_resolved(candidates: Set[str], threads: int=DEFAULT_THREADS) -> Set[str]:
    print("[*] Resolving candidates (deduplicate + verify DNS)...")
    resolved = set()
    with concurrent.futures.ThreadPoolExecutor(max_workers=threads) as ex:
        futures = {ex.submit(resolve_host, h): h for h in candidates}
        for fut in concurrent.futures.as_completed(futures):
            ok = fut.result()
            host = futures[fut]
            if ok:
                resolved.add(host)
    return resolved

def check_alive_batch(resolved_subs: Set[str], threads: int=DEFAULT_THREADS) -> Set[str]:
    print("[*] Checking which hosts are active (HTTP/HTTPS)...")
    alive = set()
    with concurrent.futures.ThreadPoolExecutor(max_workers=threads) as ex:
        futures = {ex.submit(check_http_alive, h): h for h in resolved_subs}
        for fut in concurrent.futures.as_completed(futures):
            ok = fut.result()
            host = futures[fut]
            if ok:
                print(f"[+] Active (web): {host}")
                alive.add(host)
    return alive

def save_to_file(items: Set[str], filename: str):
    with open(filename, 'w', encoding='utf-8') as f:
        for i in sorted(items):
            f.write(i + '\n')
    print(f"[*] Saved {len(items)} items to {filename}")

def main():
    parser = argparse.ArgumentParser(description="Subdomain finder that outputs active (HTTP/HTTPS) subdomains.")
    parser.add_argument("domain", help="Target domain (e.g., example.com)")
    parser.add_argument("-w", "--wordlist", default="wordlist.txt", help="Wordlist file (one label per line)")
    parser.add_argument("-o", "--output", default="active_subdomains.txt", help="Output file for active subdomains")
    parser.add_argument("-t", "--threads", type=int, default=DEFAULT_THREADS, help="Number of threads")
    parser.add_argument("--no-crtsh", action="store_true", help="Disable crt.sh lookup")
    args = parser.parse_args()

    # load wordlist
    wordlist = []
    try:
        wordlist = load_wordlist(args.wordlist)
    except FileNotFoundError:
        print(f"[!] Wordlist not found: {args.wordlist}", file=sys.stderr)
        sys.exit(1)

    # brute-force subdomains (DNS check included)
    brute_results = brute_force(args.domain, wordlist, threads=args.threads)

    # optional crt.sh passive gather
    crt_results = set()
    if not args.no_crtsh:
        crt_results = fetch_crtsh(args.domain)
        print(f"[*] crt.sh returned {len(crt_results)} candidates")

    # combine and resolve candidates
    candidates = set(brute_results) | set(crt_results)
    print(f"[*] Total candidates before DNS verification: {len(candidates)}")
    resolved = filter_resolved(candidates, threads=args.threads)
    print(f"[*] Resolved hosts: {len(resolved)}")

    # check which ones are web-active
    alive = check_alive_batch(resolved, threads=args.threads)
    print(f"[*] Active web hosts found: {len(alive)}")

    # save
    save_to_file(alive, args.output)

if __name__ == "__main__":
    # suppress insecure request warnings when verify=False is used for HTTPS
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    main()
