import requests
import dns.resolver
import argparse

# Timeout in seconds for HTTP requests
TIMEOUT = 3

def load_wordlist(path):
    with open(path, 'r') as f:
        return [line.strip() for line in f.readlines() if line.strip()]

def brute_force(domain, wordlist):
    print("[*] Starting DNS brute-force...")
    found = []
    for word in wordlist:
        subdomain = f"{word}.{domain}"
        try:
            dns.resolver.resolve(subdomain, 'A')
            print(f"[+] Found: {subdomain}")
            found.append(subdomain)
        except (dns.resolver.NXDOMAIN, dns.resolver.NoAnswer, dns.resolver.LifetimeTimeout):
            continue
    return found

def fetch_crtsh(domain):
    print("[*] Fetching subdomains from crt.sh...")
    url = f"https://crt.sh/?q=%25.{domain}&output=json"
    try:
        resp = requests.get(url, timeout=10)
        subdomains = set()
        if resp.status_code == 200:
            data = resp.json()
            for entry in data:
                name = entry['name_value']
                for sub in name.split('\n'):
                    if sub.endswith(domain):
                        subdomains.add(sub.strip())
        return list(subdomains)
    except Exception as e:
        print(f"[!] Error querying crt.sh: {e}")
        return []

def save_to_file(subdomains, filename):
    with open(filename, 'w') as f:
        for sub in sorted(set(subdomains)):
            f.write(sub + '\n')
    print(f"[*] Results saved to {filename}")

def is_active(subdomain):
    """Check if the subdomain is active (responding on HTTP/HTTPS)."""
    urls = [f"http://{subdomain}", f"https://{subdomain}"]
    for url in urls:
        try:
            response = requests.get(url, timeout=TIMEOUT)
            if response.status_code < 500:
                return True
        except requests.RequestException:
            continue
    return False

def extract_active_subdomains(subdomain_list):
    print("\n[*] Checking which subdomains are active...")
    active_subdomains = []
    for subdomain in subdomain_list:
        if is_active(subdomain):
            print(f"[+] Active: {subdomain}")
            active_subdomains.append(subdomain)
        else:
            print(f"[-] Inactive: {subdomain}")
    return active_subdomains

def main():
    parser = argparse.ArgumentParser(description="Subdomain Finder + Active Checker")
    parser.add_argument("domain", help="Target domain (e.g., example.com)")
    parser.add_argument("-w", "--wordlist", default="wordlist.txt", help="Path to wordlist file")
    parser.add_argument("-o", "--output", help="Save all found subdomains to this file")
    parser.add_argument("-a", "--active_output", help="Save active subdomains to this file")
    args = parser.parse_args()

    # Load wordlist
    wordlist = load_wordlist(args.wordlist)

    # Brute force subdomains
    brute_results = brute_force(args.domain, wordlist)

    # Get crt.sh subdomains
    crtsh_results = fetch_crtsh(args.domain)

    # Combine all found subdomains
    all_subdomains = sorted(set(brute_results + crtsh_results))
    print(f"\n[*] Total unique subdomains found: {len(all_subdomains)}")
    for sub in all_subdomains:
        print(f" - {sub}")

    # Save all found subdomains if requested
    if args.output:
        save_to_file(all_subdomains, args.output)

    # Check active subdomains
    active_subdomains = extract_active_subdomains(all_subdomains)

    # Save active subdomains if requested
    if args.active_output:
        save_to_file(active_subdomains, args.active_output)

    print(f"\n[*] Total active subdomains found: {len(active_subdomains)}")

if __name__ == "__main__":
    main()
