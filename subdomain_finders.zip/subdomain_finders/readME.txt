#commands to run
env\Scripts\activate  (Windows)
source env/Scripts/activate  (Linux)

python script.py example.com -w wordlist.txt -o subdomains.txt -a active_subdomains.txt